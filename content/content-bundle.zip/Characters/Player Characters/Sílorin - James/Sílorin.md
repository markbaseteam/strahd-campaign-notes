---
dg-publish: true
tags: ["Player Character"]
---
# Sílorin
## Backstory
## These notes are old asf ngl pls don't listen asseblief 🙏
(it's not at all accurate)
You spent years learning the lore of the multiverse. You scoured manuscripts, studied scrolls, and listened to the greatest experts on the subjects that interest you. Your efforts have made you a master in your fields of study.

Sílorin was a curious fellow who had wandered the lands of [[Barovia]] for longer than most could remember. To most he was a local curiosity that appeared once every few years, for he was a nomad, and did not stay in one place for much longer than a month. Being a moon elf, he was infatuated with the curiosities of humanity, fascinated by their peculiar ways, which he himself did not fully understand, leading him to come off as mildly clueless but well meaning. He was intelligent, of course, being a wizard and an elf, but he lacked a full understanding of human culture, even if he had been travelling between them for nearly half a century. He often brought happiness to those who, in a sad and gloomy country often needed it, using his skills with prestiditation to entertain children by making sparkling displays of things that they could only scarcely imagine. He was recognized by his blue-gray flat-crowned wide-brimmed hat ([Illustrated example](https://imgur.com/63sgDBY)) and cloak, made of elven cloth from his faraway homeland. He carried with him a staff made of a hardy wood, with curiosities hanging from it. Embedded within it is a stone of quartz, which itself does not possess magic, but is used to light up using one of his cantrips. Sílorin does not share much of his past, rather keeping to himself about matters which concern himself.

# Backstory


## Important possessions
### The Necronomicon
[[Characters/Player Characters/Sílorin - James/Possessions/The Necronomicon]] is an ancient tomb of forbidden knowledge.