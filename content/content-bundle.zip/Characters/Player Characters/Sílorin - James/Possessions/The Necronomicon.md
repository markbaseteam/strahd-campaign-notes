---
dg-publish: true
tags: ["Quest Item", "Ancient Evil"]
---
![[Important Items/The Necronomicon|The Necronomicon]]