---
dg-publish: true
tags: ["Player Character"]
---
> [!attention]
> # This entry is not complete
> It will be further expanded on if/when the party discovers more information about this entry

