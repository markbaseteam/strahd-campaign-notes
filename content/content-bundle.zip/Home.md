---
dg-home: true
dg-publish: true
dg-show-backlinks: true
---

# Home
## Table of Contents
- Characters
	- Player Characters
		- [[Giaco|Giaco]]
		- [[Sílorin|Sílorin]]
		- [[Xyrophine|Xyrophine]]
- World
	- [[Barovia|Map of Borovia]]
	- Locations
		- [[Village of Barovia|The Village of Barovia]]
		- [[The City of Villaki]]