---
dg-publish: true
tags: ["Quest Item", "Ancient Evil"]
---
> [!warning] 
> # Remember - No Metagaming!
> This is an important quest item that your character _probably doesn't know about_
> 
> ### If your character hasn't been told about this, *do not reference it in game, please*

# History
## Ancient History
The Necronomicon is a book containing eldritch knowledge which no mortal being should have access to. Said to impart a great strain upon the minds of any who read it, the knowledge held within grants the reader unmeasurable power. That power, however, comes at great cost[^1].
## Strixhaven
In more recent years, [Strixhaven](https://mtg.fandom.com/wiki/Strixhaven), the premier school for magic, acquired the book and hid it away in its darkest corner - out of the gaze of public view and, in their eyes, out of harm's way. 
### Stolen by student
[[Sílorin]] was a top student at Strixhaven, well liked by his peers, and respected by teachers for his good work-ethic and well-meaning demeanour. It was an even larger surprise when - out of nowhere - Sílorin made off with the book, disappearing from the seemingly all-seeing eyes of the Strixhaven higher-ups.
# Cult of The Necronomicon
While at Strixhaven, an underground cult of presumably students and/or teachers started worshipping the book, hailing it for its great power. Not much is known about this cult, and Sílorin only knew surface details.

[^1]: The party, and, more specifically, Sílorin, have not learned what this power (or its accompanying cost) actually is in the campaign yet.